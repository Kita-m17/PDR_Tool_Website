/*
 * Original Author: Thabo Vincent Moloi (2024 Honours Project, University of Cape Town)
 * Adapted by: Samukelisiwe (2026 Honours Project, University of Cape Town)
 * Changes: Added the sub-knowledge base trace and justifications
 *
 * Context: Used in PDR's project for lexicographic closure reasoning.
 * Purpose: Educational use only.
 */
package com.pdr.models;

import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.stream.Collectors;
import com.pdr.dtos.RankDTO;


public class LexicographicEntailment extends Entailment {
    // re-exposed as DTOs
    @JsonIgnore
    private final Ranking removedRanking;
    // Each rank = single combined formula Ri,m
    @JsonIgnore
    private final Ranking weakenedRanking;
    @JsonIgnore
    private final KnowledgeBase weakJustification;

    // surviving sub-KBs + query + answer
    private final List<SubKnowledgeBaseCheck> finalChecks;
    private final List<LexicographicStep> lexicographicSteps;

    private LexicographicEntailment(LexicographicEntailmentBuilder builder) {
        super(builder);
        this.removedRanking = builder.removedRanking;
        this.weakenedRanking = builder.weakenedRanking;
        this.weakJustification = builder.weakJustification;
        this.finalChecks = builder.finalChecks;
        this.lexicographicSteps = builder.lexicographicSteps;
    }

    public static LexicographicEntailmentBuilder builder() {
        return new LexicographicEntailmentBuilder();
    }
    
    // plain getters are for Java callers 

    public Ranking getRemovedRanking() {
        return removedRanking;
    }

    public Ranking getWeakenedRanking() {
        return weakenedRanking;
    }

    // get query checked againstsurviving sub-knowledge base
    public List<SubKnowledgeBaseCheck> getFinalChecks() {
        return finalChecks;
    }

    public List<LexicographicStep> getLexicographicSteps() {
        return lexicographicSteps;
    }

    // JSON VIEW 

    @JsonProperty("smallestWeakJustification")
    public List<String> getWeakJustification() {
        return weakJustification != null ? weakJustification.toStringList() : List.of();
    }
    @JsonProperty("removedRanking")
    public List<RankDTO> getRemovedRankingDTO() {
        return removedRanking != null
                ? removedRanking.stream().map(Rank::toDTO).collect(Collectors.toList())
                : List.of();
    }
 
    @JsonProperty("weakenedRanking")
    public List<RankDTO> getWeakenedRankingDTO() {
        return weakenedRanking != null
                ? weakenedRanking.stream().map(Rank::toDTO).collect(Collectors.toList())
                : List.of();
    }


    public static class LexicographicEntailmentBuilder extends EntailmentBuilder<LexicographicEntailmentBuilder> {
        private Ranking removedRanking = new Ranking();
        private Ranking weakenedRanking = new Ranking();
        private KnowledgeBase weakJustification = new KnowledgeBase();
        private List<SubKnowledgeBaseCheck> finalChecks = new ArrayList<>();
        private List<LexicographicStep> lexicographicSteps = new ArrayList<>();

        public LexicographicEntailmentBuilder withRemovedRanking(Ranking removedRanking) {
            this.removedRanking = removedRanking;
            return this;
        }

        public LexicographicEntailmentBuilder withWeakJustification(KnowledgeBase weakJustification) {
            this.weakJustification = weakJustification;
            return this;
        }

        public LexicographicEntailmentBuilder withWeakenedRanking(Ranking weakenedRanking) {
            this.weakenedRanking = weakenedRanking;
            return this;
        }

        public LexicographicEntailmentBuilder withFinalChecks(List<SubKnowledgeBaseCheck> finalChecks) {
            this.finalChecks = finalChecks;
            return this;
        }

        public LexicographicEntailmentBuilder withLexicographicSteps(List<LexicographicStep> lexicographicSteps) {
            this.lexicographicSteps = lexicographicSteps;
            return this;
        }

        @Override
        protected LexicographicEntailmentBuilder self() {
            return this;
        }

        @Override
        public LexicographicEntailment build() {
            return new LexicographicEntailment(this);
        }
    }
}