export interface Example{
    label: string;
    description: string;
    formulas: string[];
    query:string;
    algorithm: string;
}

export const EXAMPLES: Example[] = [
    {
        label: 'Penguin',
        description: 'Classic pengiun example: birds typically fly, but penguind do not',
        formulas: ['(bird|~flies)','(penguin=>bird)','(penguin|~!flies)'],
        query: 'penguin|~!flies',
        algorithm:'rational'
    },
    {
        label: 'Penguin Extended',
        description: 'Extended penguin example with multiple ranks',
        formulas: ['(animal|~moves)','(bird=>animal)','(bird|~flies)','(bird|~hasWings)','(penguin=>bird)','(penguin|~!flies)','(penguin|~swims)','(rockhopper=>penguin)','(rockhopper|~hasYellowFeathers)','(rockhopper|~!swims)'],
        query: 'rockhopper|~!swims',
        algorithm:'rational'
    },
    {
        label: 'Garfield',
        description: 'Garfield the cat: lazy and hates Mondays',
        formulas: ['(cat|~active)','(cat|~likesMondays)','(cat|~hasFur)','(garfield=>cat)','(garfield|~!active)','(garfield|~!likesMondays)'],
        query: 'garfield|~!active',
        algorithm: 'rational'
    },
    {
        label: 'Kittens ',
        description: 'Demonstrating Basic RelC vs. Minimal RelC example by Chipo Hamayobe',
        formulas: ['(pets=>animals)','(kittens=>cats)','(cats|~trainable)','(kittens|~!trainable)','(animals|~legs)','(animals|~wild)','(cats=>animals)','(cats|~!wild)'],
        query: 'kittens|~!wild',
        algorithm: 'minimal relevant'
    },
    {
    label: 'The Drowning Problem',
    description: "Same penguin/bird setup, but asks about wings instead of flying - watch Rational Closure lose information it shouldn't.",
    formulas: ['(bird|~flies)', '(bird|~wings)', '(penguin=>bird)', '(penguin|~!flies)'],
    query: 'penguin|~wings',
    algorithm: 'rational'

    },
    {
        label: 'Perry',
        description: 'Does perry have a bill? example by Liam De Saldanha',
        formulas: ['(perry=>platypus)','(perry|~hat)','(platypus|~!hat)','(platypus|~bill)'],
        query: 'perry|~bill',
        algorithm: 'basic relevant'
    }
]