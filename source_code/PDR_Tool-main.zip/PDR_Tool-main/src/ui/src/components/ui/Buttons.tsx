/*
 * File: Button.tsx
 * Original Author: Thabo Moloi (2024 Honours Project - University of Cape Town)
 * Used by: Nikita Martin (2026 Honours Project - University of Cape Town)
 * Purpose: Educational use only.
 */

import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../../lib/utils";

const buttonVariants = cva(
    "inline-flex items-center justify-center whitespace-nowrap rounded-lg text-sm font-medium transition-colors focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50",
    {
        variants: {
            variant: {
                default:"bg-secondary/60 text-secondary-foreground shadow-sm hover:bg-secondary/40 border",
                primary:"bg-primary text-white shadow hover:bg-primary/60",
                secondary:"border bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/40",
                outline:"border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
                ghost: "hover:bg-accent hover:text-accent-foreground",
                destructive:"bg-red-500 text-white hover:bg-red-600",
                link: "text-primary underline-offset-4 hover:underline",
            },

            size: {
                default: "h-9 px-4 py-2",
                sm: "h-8 px-3 text-xs",
                lg: "h-11 px-8 text-base",
                icon: "h-9 w-9",
            },
        },

        defaultVariants: {
            variant: "outline",
            size: "default",
        },
    }
);

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement>,VariantProps<typeof buttonVariants> {
    asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
    ({ className, variant, size, asChild = false, ...props }, ref) => {
        const Comp = asChild ? Slot : "button";
        return (
            <Comp
                className={cn(buttonVariants({ variant, size, className }))}
                ref={ref}
                {...props}
            />
        );
    }
);

Button.displayName = "Button";

export { Button, buttonVariants };