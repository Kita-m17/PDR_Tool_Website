/**
 * File: QueryInput.tsx
 * Original Author: Samukelisiwe Zwane (PDR Honours Project - University of Cape Town)
 * Context: React component for the query input
 * Purpose: Educational use only.
 */

import React, { useState } from "react";
import { Link } from "react-router-dom";
import { validateTerm } from "../../lib/formulaValidator";

interface QueryInputProps {
    onSubmit: (query: string) => void;
    defaultValue?: string;
    disabled?: boolean;
    /** Fires whenever the antecedent/consequent go valid <-> invalid, so the
     * parent can gate submission the same way FormulaCard's onValidityChange
     * gates it for the knowledge base. */
    onValidityChange?: (valid: boolean) => void;
}

/**
 * Builds the entailment query (e.g. "penguin|~!flies") from four separate
 * fields - Antecedent, Relation, Consequent, Negate - rather than a single
 * free-text input. Splitting it up means each side of the relation can be
 * validated independently and the user can't accidentally malform the
 * connective itself, at the cost of needing to reconstruct/deconstruct the
 * query string whenever it crosses the component boundary (see parseDefault
 * and the query-building logic in the first useEffect below).
 */
const QueryInput: React.FC<QueryInputProps> = ({ onSubmit, defaultValue, disabled, onValidityChange }) => {

    //parse defaultValue back into parts
    const parseDefault = (val?: string) => {
        if (!val) 
            return { antecedent: 'penguin', relation: '|~', consequent: 'flies', negate: true };

        const relation = val.includes('|~') ? '|~' : '=>';
        const parts = val.split(relation);

        const antecedent = parts[0]?.trim() || 'penguin';
        const rawConsequent = parts[1]?.trim() || 'flies';
        const negate = rawConsequent.startsWith('!');
        const consequent = negate ? rawConsequent.substring(1) : rawConsequent;
        return { antecedent, relation, consequent, negate };
    };

    const defaults = parseDefault(defaultValue); // get default vals

    //get query parts
    const [antecedent, setAntecedent] = useState(defaults.antecedent);
    const [consequent, setConsequent] = useState(defaults.consequent);
    const [relation, setRelation] = useState(defaults.relation);
    const [negate, setNegate] = useState(defaults.negate);

    // Per-field validation, recomputed on every keystroke - each side of the
    // relation is its own TERM (an atom, or a '&&'/'||' group), the same
    // grammar the knowledge base formulas use for their antecedent/consequent.
    const antecedentResult = React.useMemo(() => validateTerm(antecedent), [antecedent]);
    const consequentResult = React.useMemo(() => validateTerm(consequent), [consequent]);
    const queryValid = antecedentResult.valid && consequentResult.valid;

    //preview query
    const preview = antecedent && consequent ? `${antecedent} ${relation} ${negate ? '!':''}${consequent}` : '';

    React.useEffect(() => {
        if (antecedent && consequent) {
            const query = `${antecedent}${relation}${negate ? '!' : ''}${consequent}`;
            onSubmit(query);
        }
        onValidityChange?.(queryValid);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [antecedent, relation, consequent, negate, onSubmit, onValidityChange, queryValid]);

    // set to default
    React.useEffect(() => {
        const defaults = parseDefault(defaultValue);
        setAntecedent(defaults.antecedent);
        setRelation(defaults.relation);
        setConsequent(defaults.consequent);
        setNegate(defaults.negate);
    }, [defaultValue]);

    // shared styling between the inputs
    const fieldClass = (invalid: boolean) =>
        `w-full border rounded-lg px-3 py-2 text-sm focus:outline-none ${
            invalid ? 'border-red-400 focus:border-red-500' : 'border-border focus:border-pdr-blue'
        } ${disabled ? 'bg-accent text-muted-foreground cursor-not-allowed' : ''}`;

    return(
        <div className = "mb-8">
            <h2 className = "text-primary font-semibold mb-3">
                2. Query
                {/* <span className = "ml-2 text-blue-700 cursor-pointer">ⓘ</span> */}
                <Link
                    to="/info#query"
                    title="How to write a query"
                    aria-label="How to write a query"
                    className="ml-2 text-blue-700 hover:text-primary transition-colors"
                >
                    ⓘ
                </Link>
            </h2>
            <p className="text-muted-foreground text-sm mb-4">
                Specify the query you want to test against the knowledge base.
            </p>

            {/* Input row */}
            <div className="mt-4 flex flex-wrap items-center gap-4">
                {/* Antecedent */}
                <div className="flex flex-col gap-1 flex-1 min-w-[140px]">
                    <label className="text-sm text-gray-600"> 
                        Antecedent
                    </label>

                    <input
                        type="text"
                        disabled={disabled}
                        className={fieldClass(!antecedentResult.valid)}
                        placeholder="e.g. penguin"
                        value={antecedent}
                        onChange={(e) => setAntecedent(e.target.value)}
                    />

                    {!antecedentResult.valid && (
                        <p className="text-red-500 text-xs">{antecedentResult.error}</p>
                    )}
                </div>

                {/* Relation - connective between the antecedent & consequent */}
                <div className="flex flex-col gap-1">
                    <label className="text-sm text-gray-600">
                        Relation
                    </label>

                    <select
                        className={fieldClass(false)}
                        value={relation}
                        onChange={(e) => setRelation(e.target.value)}
                        disabled={disabled}
                    >
                        <option value="|~">|~ (defeasible)</option>
                        <option value="=>">=&gt; (classical)</option>
                    </select>
                </div>

                {/* Consequent */}
                <div className="flex flex-col gap-1 flex-1 min-w-[140px]">
                    <label className="text-sm text-gray-600">
                        Consequent
                    </label>
                    
                    <input
                        type="text"
                        disabled={disabled}
                        className={fieldClass(!consequentResult.valid)}
                        placeholder="e.g. flies"
                        value={consequent}
                        onChange={(e) => setConsequent(e.target.value)}
                    />

                    {!consequentResult.valid && (
                        <p className="text-red-500 text-xs">{consequentResult.error}</p>
                    )}
                </div>

                {/* Negate - toggle to negate the consequent */}
                <div className="flex flex-col gap-1">
                    <label className="text-sm text-gray-600">
                        Negate consequent
                    </label>

                    <div className="flex items-center gap-2 py-2">
                        <input
                            type="checkbox"
                            disabled={disabled}
                            className={`w-4 h-4 accent-pdr-blue ${disabled ? 'cursor-not-allowed opacity-50' : ''}`}
                            checked={negate}
                            onChange={(e) => setNegate(e.target.checked)}
                        />
                    </div>
                </div>

            </div>

            {/* Preview - read-only rendering of the query*/}
            {preview && (
                <p className="mt-5 text-s text-gray-600">
                    <span className="font-medium pr-2">
                        Preview:  
                    </span>

                    <span className="text-blue-600 font-mono">
                        {preview}
                    </span>
                </p>
            )}

        </div>
    );
};

export default QueryInput;