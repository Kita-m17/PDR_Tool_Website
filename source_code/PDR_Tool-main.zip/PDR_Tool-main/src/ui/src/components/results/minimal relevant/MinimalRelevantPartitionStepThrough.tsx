import React, { useState, useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { BaseRankDTO, EntailmentDTO, PartitionDTO } from '../../../api/api';
import Header from '../../layout/Header';
import AlgorithmProgress from '../../layout/AlgorithmProgress';
import Footer from '../../layout/Footer';
import { buildMinimalPartitionSteps, MinimalPartitionDebuggerStep } from './MinimalRelevantPartitionSteps';
import PowersetView, { PartitionFilter } from '../basic relevant/PowersetView';
import JustificationVisualiser from '../basic relevant/JustificationVisualiser';
import StepControls from '../StepControls';
import { ArrowLeftIcon, ArrowRightIcon } from '@radix-ui/react-icons';
import { Button } from '../../ui/Buttons';
import { baseRankSteps, BaseRankDebuggerStep } from '../baseRankSteps';

interface ResultsState {
    baseRank: BaseRankDTO;
    entailment: EntailmentDTO;
    partition: PartitionDTO;
    query: string;
    algorithm: string;
    fromComparison?: boolean;
}
function getAntecedent(formula: string): string {
    const stripped = formula.replace(/[()]/g, '');
    return stripped.split(/\|~|~\|/)[0].trim();
}
// Mirrors BasicRelevantPartitionStepThrough.tsx's structure exactly - same
// Powerset + Explanation + Justifications layout - but for Minimal Relevant
// Closure. The powerset view is fed the same full subset the backend
// checked, unchanged, same as Basic Relevant Closure. Only the explanation
// (via MinimalRelevantPartitionSteps.ts) and the justification entries
// (already reduced to `minimalSet` server-side for this algorithm) reflect
// the extra lowest-rank reduction step.
const MinimalRelevantPartitionStepThrough: React.FC = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const resultsState = location.state as ResultsState | null;
    const [filter, setFilter] = useState<PartitionFilter>('all');
    const [currentStep, setCurrentStep] = useState(0);
    const steps = resultsState ? buildMinimalPartitionSteps(resultsState.partition) : [];

    const filteredSteps = useMemo(() => {
        switch (filter) {
            case 'entailed': return steps.filter(s => s.entailed);
            case 'minimal': return steps.filter(s => s.entailed && s.minimal);
            default: return steps;
        }
    }, [steps, filter]);

    const step: MinimalPartitionDebuggerStep | undefined = filteredSteps[currentStep];
    const isLastInView = filteredSteps.length > 0 && currentStep === filteredSteps.length - 1;
    // Antecedent not exceptional (e.g. not in the KB): the backend returns no trace steps
    const noJustifications = steps.length === 0;

    const handleFilterChange = (next: PartitionFilter) => {
        setFilter(next);
        setCurrentStep(0);
    };

    if (!resultsState) {
        return (
            <div className="min-h-screen bg-accent flex flex-col">
                <Header />
                <main className="flex-1 px-8 py-6 flex items-center justify-center">
                    <div className="bg-white border border-border rounded-xl p-8 text-center max-w-md">
                        <h2 className="text-lg font-semibold text-foreground mb-2">
                            No query data found
                        </h2>
                        <p className="text-sm text-muted-foreground mb-6">
                            This page needs data from a submitted query. It looks like it was reached
                            directly - for example a page refresh, a pasted link, or a bookmark - which
                            doesn't carry that data along. Start a new query instead.
                        </p>
                        <Button variant="primary" onClick={() => navigate('/')}>
                            Back to start
                        </Button>
                    </div>
                </main>
                <Footer />
            </div>
        );
    }

    const { baseRank, entailment, partition, query, algorithm, fromComparison } = resultsState;

    return (
        <div className="min-h-screen bg-accent flex flex-col">
            <Header />

            <main className="flex-1 px-8 py-6">

                <AlgorithmProgress currentPhase="partition" />

                {/* Page header */}
                <div className="flex items-start justify-between mb-4">
                    <div>
                        <h1 className="text-2xl font-bold text-foreground">
                            Minimal Relevant Partition
                        </h1>
                        <p className="text-muted-foreground text-sm mt-1">
                            Step-by-step justification search
                        </p>

                        <p className="text-sm text-foreground mt-2 max-w-4xl">
                        A sample of sets from the powerset of the knowledge base (inclusive of all justifications of the negation of the antecedent) is checked for classical entailment of the negation of the query's antecedent in this case {"!"+getAntecedent(query)}.
                                                     This is done to find the set of defeasible statements that lead the knowledge base to conclude that no {getAntecedent(query)} exists.
                                                    Minimal entailing subsets are called justifications. Unlike Basic Justifications, Minimal Justifications keep only their lowest-ranked statement
                                                    in the justification. Statements that appear in at
                                                    least one Minimal Justification form part of the relevant partition, everything else forms part of the irrelevant partition. The relevant partition is used in addition to the base rank in the Relevant Closure Algorithm
                                                    to provide an inferentially more powerful query check. The Minimal Justifications lead us to perform Minimal Relevant Closure which is inferentially stronger than Basic Relevant Closure.


                        </p>
                    </div>

                    <Button className="text-sm text-muted-foreground border border-border rounded-lg px-4 py-2 hover:bg-white transition"
                        onClick={() => navigate('/baserank', {
                            state: { baseRank, entailment, partition, query, algorithm, fromComparison }
                        })}
                    >
                        <span className="flex items-center gap-1">
                            <ArrowLeftIcon className="h-3 w-3" />
                            Back to BaseRank
                        </span>
                    </Button>
                </div>

                {/* Query banner */}
                <div className="bg-white border border-border rounded-xl p-4 mb-4 flex items-center gap-3">
                   <span className="text-primary font-bold text-sm">Checking</span>
                                       <span className="font-mono text-foreground">{"!"+getAntecedent(query)}</span>
                </div>

                {/* Justification visualiser */}
                {(step || noJustifications) && (
                    <div className="bg-white border border-border rounded-xl p-6 mb-4">
                        <JustificationVisualiser
                            justificationsSoFar={step?.justificationsSoFar ?? []}
                            isFinalStep={isLastInView || noJustifications}
                            relevantPartition={partition.relevantPartition}
                            irrelevantPartition={partition.irrelevantPartition}
                        />
                    </div>
                )}

                {/* Powerset (left, owns the subset filter so it's always reachable)
                    + Explanation (right) side by side.  */}
                <div className="flex gap-4 mb-4">
                    <div className="bg-white border border-border rounded-xl p-6 flex-1">
                        <PowersetView
                            currentSet={step?.currentSet ?? []}
                            entailed={step?.entailed ?? false}
                            minimal={step?.minimal ?? false}
                            stepNumber={step ? currentStep + 1 : 0}
                            totalSteps={filteredSteps.length}
                            filter={filter}
                            onFilterChange={handleFilterChange}
                        />
                    </div>

                    <div className="bg-white border border-border rounded-xl p-6 flex-1">
                        <h3 className="text-primary font-semibold mb-4 flex items-center gap-2">
                            Explanation
                        </h3>

                        {step ? (
                            <>
                                <p className="text-sm text-foreground leading-relaxed whitespace-pre-line mb-4">
                                    {step.explanation}
                                </p>

                                {/* Final base rank  */}
                                {step.entailed && step.minimal && (
                                    <div className="mb-4">
                                        <h3 className="text-primary font-semibold mb-3">
                                            Final Base Rank Table
                                        </h3>

                                        <table className="w-full border-collapse">
                                            <tbody>
                                                {baseRank.ranking.map((rank) => (
                                                    <tr key={rank.rankNumber} className="border-b border-border">
                                                        <td className="py-3 px-4 font-semibold text-sm w-24 text-primary">
                                                            Rank {rank.rankName}
                                                        </td>

                                                        <td className="py-3 px-4">
                                                            <div className="flex flex-wrap gap-2">
                                                                {rank.knowledgeBase.map((f, i) => (
                                                                    <span key={i} className={`font-mono text-sm ${step.currentSet.includes(f) ? 'text-amber-600 font-semibold' : 'text-foreground'}`}>
                                                                        {f}
                                                                    </span>
                                                                ))}
                                                            </div>
                                                        </td>
                                                    </tr>
                                                ))}

                                                {baseRank.ranking.length === 0 && (
                                                    <tr>
                                                        <td colSpan={2} className="py-4 text-center text-xs text-muted-foreground italic">
                                                            No ranks in the base rank
                                                        </td>
                                                    </tr>
                                                )}
                                            </tbody>
                                        </table>
                                    </div>
                                )}


                                {step.minimal && step.minimalSet.length > 0 && (
                                    <div className="rounded-lg border border-sky-200 bg-sky-50 p-3 mb-4">
                                        <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-sky-900">
                                            Minimal Justification
                                        </p>
                                        <p className="font-mono text-sm text-sky-900">
                                            {` ${step.minimalSet.join(', ')} `}
                                        </p>
                                    </div>
                                )}

                                {isLastInView && (
                                    <div className="mt-4 rounded-lg p-4 border bg-emerald-50 border-green-200">
                                        <p className="font-bold text-green-700 mb-1">
                                            ✓ Partition Complete
                                        </p>
                                    </div>
                                )}
                            </>
                        ) : (
                            <p className="text-sm text-muted-foreground italic">
                                {noJustifications
                                    ? `No justifications were found`
                                    : 'No subsets match this filter'}
                            </p>
                        )}
                    </div>
                </div>

                {/* Step controls + continue, only once a step exists */}
                {step && (
                    <>
                        <div className="bg-white border border-border rounded-xl p-4">
                            <StepControls
                                current={currentStep}
                                total={filteredSteps.length}
                                onStart={() => setCurrentStep(0)}
                                onBack={() => setCurrentStep(prev => Math.max(0, prev - 1))}
                                onNext={() => setCurrentStep(prev => Math.min(filteredSteps.length - 1, prev + 1))}
                                onEnd={() => setCurrentStep(filteredSteps.length - 1)}
                            />
                        </div>

                        {isLastInView && (
                            <div className="flex justify-end mt-4">
                                <Button variant="primary" size="lg"
                                    onClick={() => 
                                        navigate('/results/relevant/basic', {
                                        state: { baseRank, entailment, partition, query, algorithm, fromComparison }
                                    })}
                                >
                                    Continue to Relevant Closure
                                    <ArrowRightIcon className="ml-2 h-4 w-4" />
                                </Button>
                            </div>
                        )}
                    </>
                )}

                {/* No justifications: nothing to step through, but still allow moving on */}
                {noJustifications && (
                    <div className="flex justify-end mt-4">
                        <Button variant="primary" size="lg"
                            onClick={() => navigate('/results/relevant/basic', {
                                state: { baseRank, entailment, partition, query, algorithm, fromComparison }
                            })}
                        >
                            Continue to Relevant Closure
                            <ArrowRightIcon className="ml-2 h-4 w-4" />
                        </Button>
                    </div>
                )}

            </main>

            <Footer />
        </div>
    );
};

export default MinimalRelevantPartitionStepThrough;
