import React, { useState, useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { BaseRankDTO, EntailmentDTO, PartitionDTO } from '../../../api/api';
import Header from '../../layout/Header';
import AlgorithmProgress from '../../layout/AlgorithmProgress';
import Footer from '../../layout/Footer';
import { buildPartitionSteps, PartitionDebuggerStep } from './PartitionSteps';
import PowersetView, { PartitionFilter } from './PowersetView';
import JustificationVisualiser from './JustificationVisualiser';
import StepControls from '../StepControls';
import { ArrowLeftIcon, ArrowRightIcon } from '@radix-ui/react-icons';
import { Button } from '../../ui/Buttons';

interface ResultsState {
    baseRank: BaseRankDTO;
    entailment: EntailmentDTO;
    partition: PartitionDTO;
    query: string;
    algorithm: string;
}
function getAntecedent(formula: string): string {
    const stripped = formula.replace(/[()]/g, '');
    return stripped.split(/\|~|~\|/)[0].trim();
}
const BasicRelevantPartitionStepThrough: React.FC = () => {
    const location = useLocation();
    const navigate = useNavigate();
    

    const resultsState = location.state as ResultsState | null;

    const [filter, setFilter] = useState<PartitionFilter>('all');
    const [currentStep, setCurrentStep] = useState(0);


    const steps = resultsState ? buildPartitionSteps(resultsState.partition) : [];


    const filteredSteps = useMemo(() => {
        switch (filter) {
            case 'entailed': return steps.filter(s => s.entailed);
            case 'minimal': return steps.filter(s => s.entailed && s.minimal);
            default: return steps;
        }
    }, [steps, filter]);

    const step: PartitionDebuggerStep | undefined = filteredSteps[currentStep];
    const isLastInView = filteredSteps.length > 0 && currentStep === filteredSteps.length - 1;
    // Antecedent not exceptional (e.g. not in the KB): the backend returns no trace steps
    const noJustifications = steps.length === 0;

    const handleFilterChange = (next: PartitionFilter) => {
        setFilter(next);
        setCurrentStep(0);
    };

    if (!resultsState) {
        return (
            <div className="min-h-screen bg-accent flex flex-col">
                <Header />
                <main className="flex-1 px-8 py-6 flex items-center justify-center">
                    <div className="bg-white border border-border rounded-xl p-8 text-center max-w-md">
                        <h2 className="text-lg font-semibold text-foreground mb-2">
                            No query data found
                        </h2>
                        <p className="text-sm text-muted-foreground mb-6">
                            This page needs data from a submitted query. It looks like it was reached
                            directly - for example a page refresh, a pasted link, or a bookmark - which
                            doesn't carry that data along. Start a new query instead.
                        </p>
                        <Button variant="primary" onClick={() => navigate('/')}>
                            Back to start
                        </Button>
                    </div>
                </main>
                <Footer />
            </div>
        );
    }

    const { baseRank, entailment, partition, query, algorithm } = resultsState;

    return (
        <div className="min-h-screen bg-accent flex flex-col">
            <Header />

            <main className="flex-1 px-8 py-6">

                <AlgorithmProgress currentPhase="partition" />

                {/* Page header */}
                <div className="flex items-start justify-between mb-4">
                    <div>
                        <h1 className="text-2xl font-bold text-foreground">
                            Relevant Partition
                        </h1>
                        <p className="text-muted-foreground text-sm mt-1">
                            Step-by-step justification search
                        </p>

                        <p className="text-sm text-foreground mt-2 max-w-2xl">
                            A sample of sets from the powerset of the knowledge base (inclusive of all justifications of the negation of the antecedent) is checked for classical entailment of the negation of the query's antecedent in this case {"!"+getAntecedent(query)}.
                             This is done to find the set of defeasible statements that lead the knowledge base to conclude that no {getAntecedent(query)} exists.
                            Minimal entailing subsets are called justifications. The statements that appear in at
                            least one justification form part of the relevant partition, everything else forms part of the irrelevant partition. The relevant partition is used in addition to the base rank in the Relevant Closure Algorithm
                            to provide an inferentially more powerful query check.
                        </p>
                    </div>

                    <Button className="text-sm text-muted-foreground border border-border rounded-lg px-4 py-2 hover:bg-white transition"
                        onClick={() => navigate('/baserank', {
                            state: { baseRank, entailment, partition, query, algorithm }
                        })}
                    >
                        <span className="flex items-center gap-1">
                            <ArrowLeftIcon className="h-3 w-3" />
                            Back to BaseRank
                        </span>
                    </Button>
                </div>

                {/* Query banner */}
                <div className="bg-white border border-border rounded-xl p-4 mb-4 flex items-center gap-3">
                    <span className="text-primary font-bold text-sm">Checking</span>
                    <span className="font-mono text-foreground">{"!"+getAntecedent(query)}</span>
                </div>

                {/* Justification visualiser, full width - only meaningful once a step exists */}
                {(step || noJustifications) && (
                    <div className="bg-white border border-border rounded-xl p-6 mb-4">
                        <JustificationVisualiser
                            justificationsSoFar={step?.justificationsSoFar ?? []}
                            isFinalStep={isLastInView || noJustifications}
                            relevantPartition={partition.relevantPartition}
                            irrelevantPartition={partition.irrelevantPartition}
                        />
                    </div>
                )}

                {/* Powerset
                    + Explanation (right) side by side */}
                <div className="flex gap-4 mb-4">
                    <div className="bg-white border border-border rounded-xl p-6 flex-1">
                        <PowersetView
                            currentSet={step?.currentSet ?? []}
                            entailed={step?.entailed ?? false}
                            minimal={step?.minimal ?? false}
                            stepNumber={step ? currentStep + 1 : 0}
                            totalSteps={filteredSteps.length}
                            filter={filter}
                            onFilterChange={handleFilterChange}
                        />
                    </div>

                    <div className="bg-white border border-border rounded-xl p-6 flex-1">
                        <h3 className="text-primary font-semibold mb-4 flex items-center gap-2">
                            Explanation
                        </h3>

                        {step ? (
                            <>
                                <p className="text-sm text-foreground leading-relaxed whitespace-pre-line mb-4">
                                    {step.explanation }
                                </p>

                                {isLastInView && (
                                    <div className="mt-4 rounded-lg p-4 border bg-green-50 border-green-200">
                                        <p className="font-bold text-green-700 mb-1">
                                            ✓ Partition Complete
                                        </p>

                                    </div>
                                )}
                            </>
                        ) : (
                            <p className="text-sm text-muted-foreground italic">
                                {noJustifications
                                    ? `No justifications were found: the knowledge base does not classically entail !${getAntecedent(query)}, so ${getAntecedent(query)} is not exceptional (this includes the case where ${getAntecedent(query)} does not appear in the knowledge base). The relevant partition is therefore empty and every statement is irrelevant, so Relevant Closure will not remove any statements.`
                                    : 'No subsets match this filter - try a different option on the left.'}
                            </p>
                        )}
                    </div>
                </div>

                {/* Step controls + continue, only once a step exists */}
                {step && (
                    <>
                        <div className="bg-white border border-border rounded-xl p-4">
                            <StepControls
                                current={currentStep}
                                total={filteredSteps.length}
                                onStart={() => setCurrentStep(0)}
                                onBack={() => setCurrentStep(prev => Math.max(0, prev - 1))}
                                onNext={() => setCurrentStep(prev => Math.min(filteredSteps.length - 1, prev + 1))}
                                onEnd={() => setCurrentStep(filteredSteps.length - 1)}
                            />
                        </div>

                        {isLastInView && (
                            <div className="flex justify-end mt-4">
                                <Button variant="primary" size="lg"
                                    onClick={() => navigate('/results/relevant/basic', {
                                        state: { baseRank, entailment, partition, query, algorithm }
                                    })}
                                >
                                    Continue to Relevant Closure
                                    <ArrowRightIcon className="ml-2 h-4 w-4" />
                                </Button>
                            </div>
                        )}
                    </>
                )}

                {/* No justifications: nothing to step through, but still allow moving on */}
                {noJustifications && (
                    <div className="flex justify-end mt-4">
                        <Button variant="primary" size="lg"
                            onClick={() => navigate('/results/relevant/basic', {
                                state: { baseRank, entailment, partition, query, algorithm }
                            })}
                        >
                            Continue to Relevant Closure
                            <ArrowRightIcon className="ml-2 h-4 w-4" />
                        </Button>
                    </div>
                )}

            </main>

            <Footer />
        </div>
    );
};

export default BasicRelevantPartitionStepThrough;
